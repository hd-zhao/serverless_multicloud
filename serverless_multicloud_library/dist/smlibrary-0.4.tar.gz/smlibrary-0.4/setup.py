from setuptools import setup, find_packages

setup(
    name='smlibrary',
    version='0.4',
    license='MIT',
    author="",
    author_email='',
    packages=find_packages('src'),
    package_dir={'': 'src'},
    url='',
    keywords='',
    install_requires=[
        
      ],

)