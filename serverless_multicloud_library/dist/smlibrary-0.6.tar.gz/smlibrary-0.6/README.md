# Serverless Multi-Cloud Library

We have uploaded the package to PYPI in order to let it be used for writing application benchmarks. Although this library function is currently limited, it is enough to verify our ideas. 

## Authentication
You need to prepare your own credential file for the library to access providers services, as the format in [`crendential`](https://github.com/hd-zhao/serverless_multicloud/tree/main/credential). This library can also be modified to support more fine-grained configurations as needed.



## Useful Links
[How to Upload Your Python Package to PyPI](https://towardsdatascience.com/how-to-upload-your-python-package-to-pypi-de1b363a1b3)


## HTTP Trigger
At this time, we only support unauthorization invocation types for GCF

## Object Storage
The library currently supports for serveral services used in the evaluation section. 




